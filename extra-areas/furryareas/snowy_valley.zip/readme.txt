
                                  
    x---------------------------------------------------------------------x
    |                                                                     |
    |                SNOWY VALLEY ZONE - FOR CIRCLEMUD 3.0                |
    |                                                                     |
    |                     Written in 2001 by Crazyman                     |
    |                        www.nt.net/saarinen                          |
    |                                                                     |
    x---------------------------------------------------------------------x
                                                                 
    
     I originally decided to make this zone a place to connect new zones
     north of Midgaard. Later on, I decided to add a ski hill and under-
     ground temple. This zone contains about 100 rooms, 3 shops, 1 death
     trap, several new items, and a bunch of new mobs. In a small cave at
     the southernmost part of the zone is a locked room, guarded by a 
     mob. Inside the room is the "Belt of the Ancients", a good piece of
     equipment that gives 10 AC, +4 hitroll and +2 damroll. You might want
     to check out the difficulty of the mob guarding the belt and ensure
     that he's strong enough for your MUD. You don't want players gettting
     good equipment too easily! :)

                 
     Written entirely from scratch in WordPad. Feel free to edit, modify,
     and do what you want with this zone!


    x---------------------------------------------------------------------x
    x---------------------------------------------------------------------x


