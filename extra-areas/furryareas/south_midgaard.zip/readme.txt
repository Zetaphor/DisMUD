    

    x---------------------------------------------------------------------x
    |                                                                     |
    |            NEW SOUTHERN MIDGAARD ZONE - FOR CIRCLEMUD 3.0           |
    |                                                                     |
    |                      Written in 2002 by Crazyman                    |
    |                         www.nt.net/saarinen                         |
    |                                                                     |
    x---------------------------------------------------------------------x

     Notes:
     ------                                                                 
     I found the stock Southern Midgaard to be really confusing, so I
     decided to write a new one. This new zone features about 100 rooms,
     several new shops, a theatre, and a curling rink. I've used a few
     of the old Southern Midgaard rooms and objects, but everything else
     is totally different.

     Stuff You Need to Change:
     -------------------------
     The Chain
        1. In 79.wld, find room 7914.
        2. Change the room leading down (D5) to 3135.        

     The Southwestern Gate:
        1. In 35.wld, find room 3505. Change the room leading north (D0) 
           to 3112.

     The Central Bridge/The Dump
        1. In 30.wld, find room 3025 (The Common Square). Change the room 
           leading south (D2) to 3118.
        2. In 30.wld, find room 3030 (The Dump). Change the room leading
           north (D0) to 3044.
        3. In 30.wld, find room 3044 (Poor Alley). Add a room leading
           south (D2) to room 3030 (The Dump).       
                            
      (You don't HAVE to make the above changes. They are just what I
       decided to do on my MUD. Place the zone wherever YOU want!)
   
    x---------------------------------------------------------------------x
    |         Written  entirely from  scratch in WordPad.  Feel           |
    |         free to edit, modify, and redistribute this zone!           |    
    x---------------------------------------------------------------------x