
                                  
    x---------------------------------------------------------------------x
    |                                                                     |
    |               STARSHIP ENTERPRISE - FOR CIRCLEMUD 3.0               |
    |                                                                     |
    |                    Written in 2001 by Crazyman                      |
    |                        www.nt.net/saarinen                          |
    |                                                                     |
    x---------------------------------------------------------------------x
      

     I created this zone because I'm a fan of the show Star Trek: The Next
     Generation. This zone features all of the main characters from the
     show, and many of the items too. On my MUD, I have a wear slot for
     the face (#18), and Geordi's VISOR is facial wear. You might want to
     change the 18 to something else, or it's going to give you errors.
     This zone features about 45 rooms, and is good for players of level
     45-50, on my MUD at least. Everyone except for the ensigns, Picard,
     and Data are rougly a bit stronger than Jupiter. Data and Picard
     are much harder, and the ensigns are easier. I have a spot for a
     holodeck, but I haven't added anything in yet.
               
     Written entirely from scratch in WordPad. Feel free to edit, modify,
     and do what you want with this zone!

    x---------------------------------------------------------------------x
    x---------------------------------------------------------------------x


