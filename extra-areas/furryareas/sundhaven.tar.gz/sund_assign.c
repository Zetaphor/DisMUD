/* Assigns for the Town of Sundhaven  */

SPECIAL(sund_earl);
SPECIAL(hangman);  
SPECIAL(blinder);
SPECIAL(silktrader);
SPECIAL(butcher);   
SPECIAL(idiot);  
SPECIAL(athos);
SPECIAL(stu);
SPECIAL(marbles);

ASSIGNMOB(6600, sund_earl);        /* Earl of Sundhaven */
ASSIGNMOB(6601, cityguard);
ASSIGNMOB(6602, hangman);
ASSIGNMOB(6664, postmaster);
ASSIGNMOB(6656, guild_guard);
ASSIGNMOB(6655, guild_guard); 
ASSIGNMOB(6658, guild_guard);
ASSIGNMOB(6657, guild_guard);
ASSIGNMOB(6666, stu);
ASSIGNMOB(6606, fido);             /* Smoke rat */
ASSIGNMOB(6616, guild);
ASSIGNMOB(6619, guild);
ASSIGNMOB(6617, guild);  
ASSIGNMOB(6618, guild);
ASSIGNMOB(6659, cityguard);
ASSIGNMOB(6660, cityguard);    
ASSIGNMOB(6607, thief);
ASSIGNMOB(6648, butcher);
ASSIGNMOB(6661, blinder);
ASSIGNMOB(6637, silktrader);
ASSIGNMOB(6615, idiot);
ASSIGNMOB(6653, athos);
ASSIGNOBJ(6612, bank);
ASSIGNOBJ(6647, marbles);
ASSIGNOBJ(6709, marbles);


