
                                  
    x---------------------------------------------------------------------x
    |                                                                     |
    |                APE VILLAGE ZONE - FOR CIRCLEMUD 3.0                 |
    |                                                                     |
    |                     Written in 2001 by Crazyman                     |
    |                         www.nt.net/saarinen                         |
    |                                                                     |
    x---------------------------------------------------------------------x
                                                                 
    
     This is the first zone I ever wrote. It's based on the original 1968
     Planet of the Apes movie, and features approximately 100 rooms, 1 
     shop, several new items, and a bunch of new mobs. This zone is good
     for characters in the level 10 - 20 range. The zone is currently 
     attached to the world north of room 6090, which is just before the
     forest west of Midgaard.

                   
     Written entirely from scratch in WordPad. Feel free to edit, modify,
     and do what you want with this zone!


    x---------------------------------------------------------------------x
    x---------------------------------------------------------------------x


